package com.example.notbored_inicio

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.notbored_inicio.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding:ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_main)
        bind()
        onClickEvents()
        onClickEvent()

    }
    private fun bind() {
        this.binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(this.binding.root)
    }
    private fun onClickEvents() {

        fun checkValor() {
            val number:Int
            if (this.binding.inicioEtNumParticipants.text.isNotEmpty() && (this.binding.inicioEtNumParticipants > 1)) {
                this.binding.btnStart.isEnabled (false)
                this.binding.btnStart.setOnClickListener {
                    intent.putExtra("Intent Number",this.binding.inicioEtNumParticipants.setText(Int,Int) )
                    startActivity(Intent(this, Activities::class.java ))
//                    saveNumParticipants = readLine() ?.toInt() as
//                            var saveNumParticipants = this.binding.inicioEtNumParticipants
//                    saveNumParticipants = readLine() ?.toInt() as
                }
            } else {
                this.binding.btnStart.setEnabled(true);
            }
        }
    }

    private fun onClickEvent() {
        this.binding.inicioTermsConditions.setOnClickListener {
            startActivity(Intent(this, termsAndConditions::class.java ))
        }
    }

}

