package com.example.notbored_inicio

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.notbored_inicio.databinding.ActivityActivitiesBinding
import com.example.notbored_inicio.databinding.ActivityTermsAndConditionsBinding

class Activities : AppCompatActivity() {
    private lateinit var binding: ActivityActivitiesBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_activities)
        bind()
        onClickEvents()
        onClickEvent()
    }

    private fun bind() {
        this.binding = ActivityActivitiesBinding.inflate(layoutInflater)
        setContentView(this.binding.root)
    }
    private fun onClickEvents() {
        this.binding.iconoActivities.setOnClickListener {
//            val randomValues = List() { Random.nextInt(0, 1) }
//            println(randomValues)
            startActivity(Intent(this, Random::class.java ))
        }
    }
    private fun onClickEvent() {
        this.binding.listaActivities.setOnClickListener {
            startActivity(Intent(this, Recreational::class.java ))
        }
    }
}