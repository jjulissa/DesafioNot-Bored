package com.example.notbored_inicio.entity

data class Categories(val id:Int, val name:String)
