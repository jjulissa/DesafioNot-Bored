package com.example.notbored_inicio

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.notbored_inicio.databinding.ActivityRandomBinding
import com.example.notbored_inicio.databinding.ActivityRecreationalBinding

class Recreational : AppCompatActivity() {
    private lateinit var binding: ActivityRecreationalBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_recreational)
        bind()
        onClickEvents()
        onClickEvent()
    }

    private fun bind() {
        this.binding = ActivityRecreationalBinding.inflate(layoutInflater)
        setContentView(this.binding.root)
    }
    private fun onClickEvents() {
        this.binding.iconoRecreational.setOnClickListener {
            startActivity(Intent(this, Activities::class.java ))
        }
    }
    private fun onClickEvent() {
        this.binding.btnRecreationalTry.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java ))
        }
    }
}