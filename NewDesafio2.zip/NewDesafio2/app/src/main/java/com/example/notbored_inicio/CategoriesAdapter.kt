package com.example.notbored_inicio

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.notbored_inicio.databinding.ItemRecyclerBinding
import com.example.notbored_inicio.entity.Categories

typealias categoriesClick = (categories: Categories) -> Unit

class CategoriesAdapter: RecyclerView.Adapter<CategoriesAdapter.CategoriesViewHolder>() {

        var list:List<CategoriesViewHolder> = listOf()
            set(value) {
                field = value
                notifyDataSetChanged()
            }
        var categoriesClick: categoriesClick ?= null

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):
                CategoriesAdapter.CategoriesViewHolder =
            CategoriesViewHolder(ItemRecyclerBinding.inflate(LayoutInflater.from(parent.context), parent, false))


        override fun onBindViewHolder(holder: CategoriesAdapter.CategoriesViewHolder, position: Int) {
            TODO("Not yet implemented")
//            holder.bind(this.list[position])
        }
        override fun getItemCount(): Int = this.list.size


        inner class CategoriesViewHolder (private val binding: ItemRecyclerBinding): RecyclerView.ViewHolder(binding.root){
            fun bind(categories: Categories) {
                binding.apply {
                    this.
                    etRecy.text = categories.name
                    this.imageView2.setOnClickListener{
                        this@CategoriesAdapter.categoriesClick?.let {
                            it(categories)
                        }
                    }
                }
            }
        }
}