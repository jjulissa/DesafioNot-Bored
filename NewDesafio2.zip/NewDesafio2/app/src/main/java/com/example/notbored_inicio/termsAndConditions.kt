package com.example.notbored_inicio

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.notbored_inicio.databinding.ActivityMainBinding
import com.example.notbored_inicio.databinding.ActivityTermsAndConditionsBinding

class termsAndConditions : AppCompatActivity() {
    private lateinit var binding:ActivityTermsAndConditionsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_terms_and_conditions)
    }

    private fun bind() {
        this.binding = ActivityTermsAndConditionsBinding.inflate(layoutInflater)
        setContentView(this.binding.root)
    }
    private fun onClickEvents() {
                this.binding.iconoX.setOnClickListener {
                    startActivity(Intent(this, MainActivity::class.java ))
        }
    }
}